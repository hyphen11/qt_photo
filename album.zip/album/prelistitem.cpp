#include "prelistitem.h"

prelistitem::prelistitem(const QIcon &icon, const QString &text, const int &index,
                         QListWidget *view, int type):
    QListWidgetItem(icon,"",view,type),_index(index),_path(text)
{

}

int prelistitem::Getindex()
{
    return _index ;
}

QString prelistitem::Getpath()
{
    return _path;
}
