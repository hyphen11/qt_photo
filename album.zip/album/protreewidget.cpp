#include "protreewidget.h"
#include"protreeitem.h"
#include"const.h"
#include "removepro.h"
#include"sildeshow.h"
#include<QDir>
#include<QGuiApplication>
#include<QAction>
#include<QMenu>
#include<QDebug>
#include<QFileDialog>
#include<QProgressDialog>
protreewidget::protreewidget(QWidget *parent ) :QTreeWidget(parent),_active_item(nullptr),
    right_btn_item(nullptr),_dialog_progress(nullptr),_selected_item(nullptr),_thread_open_pro(nullptr),_thread_create_pro(nullptr),open_progressdlg(nullptr)
{
    this->setHeaderHidden(true);
    connect(this, &protreewidget::itemPressed, this, &protreewidget::SlotItemPressed);
    _action_import = new QAction(QIcon(":/icon/import.png"),tr("导入文件"), this);
    _action_setstart = new QAction(QIcon(":/icon/core.png"),tr("设置活动项目"), this);
    _action_closepro = new QAction(QIcon(":/icon/close.png"),tr("关闭项目"), this);
    _action_slideshow = new QAction(QIcon(":/icon/slideshow.png"),tr("轮播图播放"), this);
    connect(_action_import, &QAction::triggered, this, &protreewidget::Slotimport);
    connect(_action_setstart, &QAction::triggered, this, &protreewidget::Slotsetactive);
    connect(_action_closepro, &QAction::triggered, this, &protreewidget::Slotcloseitem);
    connect(this, &protreewidget::itemDoubleClicked, this, &protreewidget::SlotDoubleClickedItem);
    connect(_action_slideshow,&QAction::triggered, this,&protreewidget::slotslideshow);
    _player=new QMediaPlayer(this);
    _play_list=new QMediaPlaylist(this);
    _play_list->setPlaybackMode(QMediaPlaylist::Loop);
    _player->setPlaylist(_play_list);
}

void protreewidget::addprototree(const QString &name, const QString &path)

{
    QDir dir(path);
    QString file_path=dir.absoluteFilePath(name);
    if(_set_path.find(file_path)!=_set_path.end()){
        return;
    }
    QDir pro_dir(file_path);
    if(!pro_dir.exists()){
        bool enable=pro_dir.mkpath(file_path);
        if(!enable){
            return;
        }

    }
    _set_path.insert(file_path);
//  protreeitem(QTreeWidgetItem*parent,const QString &name,
//                 const QString&path,QTreeWidgetItem*root,int type=Type);
//  protreeitem(QTreeWidget*view,const QString &name,const QString&path,int type=Type);
//  auto *item=new protreeitem(this,name,file_path,TreeItemPro);
    auto * item = new protreeitem(this, name, file_path,  TreeItemPro);
    item->setData(0,Qt::DisplayRole, name);
    item->setData(0,Qt::DecorationRole, QIcon(":/icon/dir.png"));
    item->setData(0,Qt::ToolTipRole, file_path);
}

void protreewidget::SlotDoubleClickedItem(QTreeWidgetItem *doubleitem, int col)
{
    if(QGuiApplication::mouseButtons()==Qt::LeftButton){
      auto* tree_doubleitem=  dynamic_cast<protreeitem*>(doubleitem);
      if(!tree_doubleitem){
          return;
      }
      int item_type=tree_doubleitem->type();
      if(item_type==TreeItemPic){
          emit sigupdateselected(tree_doubleitem->GetPath());
          _selected_item=tree_doubleitem;
      }
      else{}
    }
}

void protreewidget::SlotItemPressed(QTreeWidgetItem *pressedItem, int column)
{
    if(QGuiApplication::mouseButtons()==Qt::RightButton)
    {
        QMenu menu(this);
        qDebug() << "menu addr is " << &menu << endl;
        int itemtype = pressedItem->type();
        if (itemtype == TreeItemPro)
        {

            right_btn_item = pressedItem;//点击的区域
            menu.addAction(_action_import);
            menu.addAction(_action_setstart);
            menu.addAction(_action_closepro);
            menu.addAction(_action_slideshow);
            menu.exec(QCursor::pos());   //菜单弹出位置为鼠标点击位置
         }
    }
}

void protreewidget::Slotimport()
{
    QFileDialog file_dialog;
    file_dialog.setFileMode(QFileDialog::Directory);
    file_dialog.setWindowTitle("选择导入的文件夹");
    QString path = "";
    if(!right_btn_item){
        qDebug() << "_right_btn_item is empty" << endl;
        path = QDir::currentPath();
        return ;
    }

    path = dynamic_cast<protreeitem*>(right_btn_item)->GetPath();
    file_dialog.setDirectory(path);
    file_dialog.setViewMode(QFileDialog::Detail);
    QStringList fileNames;
      if (file_dialog.exec()){
            fileNames = file_dialog.selectedFiles();
      }
      if(fileNames.length() <= 0){
          return;
      }
      QString import_path = fileNames.at(0);
      //qDebug() << "import_path is " << import_path << endl;
      int file_count=0;
      _dialog_progress=new QProgressDialog(this);
      _thread_create_pro=std::make_shared<protreethread>(std::ref(import_path),std::ref(path),right_btn_item,
                                                         file_count,this,right_btn_item,nullptr);
      connect(_thread_create_pro.get(),&protreethread::sigupdateprogress,
              this,&protreewidget::slotupdateprogress);
      connect(_thread_create_pro.get(),&protreethread::sigfinishprogress,
              this,&protreewidget::slotfinishprogress);
      _thread_create_pro->start();
      connect(_dialog_progress,&QProgressDialog::canceled,this,&protreewidget::slotcancelprogress);
      connect(this,&protreewidget::sigcancelprogress,_thread_create_pro.get(),&protreethread::slotcancelprogress);
      _dialog_progress->setWindowTitle("请稍等");
      _dialog_progress->setFixedWidth(PROGRESS_WIDTH);
      _dialog_progress->setRange(0,PROGRESS_WIDTH);
      _dialog_progress->exec();
}

void protreewidget::slotupdateprogress(int count)
{
    if(!_dialog_progress){
        return;
    }
    if(count>=PROGRESS_MAX){
        _dialog_progress->setValue(count%PROGRESS_MAX);
    }else{
        _dialog_progress->setValue(count);
    }
}

void protreewidget::slotfinishprogress()
{
    _dialog_progress->setValue(PROGRESS_MAX);
    _dialog_progress->deleteLater();
}

void protreewidget::slotcancelprogress()
{
    emit sigcancelprogress();
    delete _dialog_progress;
    _dialog_progress=nullptr;
}

void protreewidget::Slotsetactive()
{
    if(!right_btn_item){
        return;
    }
    QFont nullfont;
    nullfont.setBold(false);
    if(_active_item){
        _active_item->setFont(0,nullfont);

    }
     _active_item= right_btn_item;
     nullfont.setBold(true);
     _active_item->setFont(0,nullfont);
}

void protreewidget::Slotcloseitem()
{
    removepro remove_pro_dialog;
    auto res=remove_pro_dialog.exec();
    if(res!=QDialog::Accepted){
        return;
    }
    bool b_remove=remove_pro_dialog.isremoved();
    auto index_right_btn=this->indexOfTopLevelItem(right_btn_item);//返回最顶层的id
    qDebug()<<"index_right_btn is"<<index_right_btn<<endl;
    auto *protreeitem_right=dynamic_cast<protreeitem *>(right_btn_item);
    auto *selectitem=dynamic_cast<protreeitem *>(_selected_item);
    auto delete_path=protreeitem_right->GetPath();
    _set_path.remove(delete_path);
    if(b_remove){
            QDir delete_dir(delete_path);
            delete_dir.removeRecursively();

    }
    if(protreeitem_right==_active_item){
        _active_item==nullptr;
        emit sigclearselected();
    }
    //关闭在目录树的显示
    if(selectitem&&protreeitem_right==selectitem->Getroot()){
        selectitem=nullptr;
        emit
    }
    delete this->takeTopLevelItem(index_right_btn);
    right_btn_item=nullptr;
}

void protreewidget::slotupdateopenprogress(int count)
{
    if(!open_progressdlg){
        return;
    }
    qDebug()<<"SlotUpOpenProgress count is " << count;
    if(count>=PROGRESS_MAX){
        open_progressdlg->setValue(count%PROGRESS_MAX);
    }else{
        open_progressdlg->setValue(count);
    }
}

void protreewidget::slotfinishopenprogress()
{
    if(!open_progressdlg){
        return;
    }
    open_progressdlg->setValue(PROGRESS_MAX);
    delete  open_progressdlg;
    open_progressdlg = nullptr;
}

void protreewidget::slotcancelopenprogress()
{
    emit sigcancelopenprogress();
    delete open_progressdlg;
    open_progressdlg=nullptr;

}

void protreewidget::slotnextshow()
{
    if(!_selected_item){
        return;
    }
    auto *curitem=dynamic_cast<protreeitem*>(_selected_item)->GetNextItem();

    if(!curitem){

        return;
    }

    //auto* nextitem=curitem->GetPath();
    emit sigupdatepic(curitem->GetPath());
    _selected_item=curitem;
    this->setCurrentItem(curitem);

}

void protreewidget::slotpreshow()
{
    if(!_selected_item){
        return;
    }
    auto *curitem=dynamic_cast<protreeitem*>(_selected_item)->GetPreItem();

    if(!curitem){

        return;
    }

    emit sigupdatepic(curitem->GetPath());
    _selected_item=curitem;
    this->setCurrentItem(curitem);
}

void protreewidget::Slotsetmusic()
{
    QFileDialog file_dlg;
    file_dlg.setFileMode(QFileDialog::ExistingFile);
    file_dlg.setWindowTitle(tr("选择音频文件"));
    file_dlg.setDirectory(QDir::currentPath());
    file_dlg.setViewMode(QFileDialog::Detail);
    file_dlg.setNameFilter("(*.mp3)");
    QStringList file_names;
    if(file_dlg.exec()){
        file_names=file_dlg.selectedFiles();
    }
    else{
        return;
    }
    if(file_names.length()<=0){
        return;
    }
    _play_list->clear();
    for(auto filename:file_names){
       _play_list->addMedia(QUrl::fromLocalFile(filename));
    }
    if(_player->state()!=QMediaPlayer::PlayingState){
        _play_list->setCurrentIndex(0);
    }
}

void protreewidget::SlotStartMusic()
{
   _player->play();
}

void protreewidget::SlotStopMusic()
{
      _player->stop();
}

void protreewidget::slotslideshow()
{
    if(!right_btn_item){
        return;
    }
    auto *right_pro_item=dynamic_cast<protreeitem*>(right_btn_item);
    auto *last_child_item= right_pro_item->GetLastPicChild();
    qDebug()<<"last_child_item:"<<last_child_item->GetPath()<<endl;
    if(!last_child_item){
        return;
    }
    auto *first_child_item=right_pro_item->GetFirstPicChild();

     qDebug()<<"first_child_item:"<<first_child_item->GetPath()<<endl;
    if(!first_child_item){
        return;
    }
    _slide_show_dlg =  std::make_shared<sildeshow>(this,first_child_item,last_child_item);

    _slide_show_dlg->setModal(true);
    _slide_show_dlg->showMaximized();
    qDebug() << "_slide_show_dlg：：：：： "  << endl;
}

void protreewidget::slot_openpro(const QString &path)
{
    if(_set_path.find(path)!=_set_path.end()){
        return;
    }
    _set_path.insert(path);
    int file_count=0;
    QDir pro_dir(path);
    QString proname=pro_dir.dirName();//返回目录的名字，不包括路径
    _thread_open_pro=std::make_shared<OpenTreeThread>(path,file_count,this,nullptr);

    //创建新的进度框
    open_progressdlg=new QProgressDialog(this);

    connect(_thread_open_pro.get(),&OpenTreeThread::SigUpdateProgress,
            this,&protreewidget::slotupdateopenprogress);
    connect(_thread_open_pro.get(),&OpenTreeThread::SigFinishProgress,
            this,&protreewidget::slotfinishopenprogress);
    connect(open_progressdlg,&QProgressDialog::canceled,this,
            &protreewidget::slotcancelopenprogress);
    connect(this,&protreewidget::sigcancelopenprogress,_thread_create_pro.get(),
            &protreethread::slotcancelopenprogress);
    _thread_open_pro->start();
    open_progressdlg->setWindowTitle("请稍等");
    open_progressdlg->setFixedWidth(PROGRESS_WIDTH);
    open_progressdlg->setRange(0,PROGRESS_WIDTH);
    open_progressdlg->exec();
}
