#include "prelistwid.h"
#include"protreeitem.h"
#include"const.h"
#include"prelistitem.h"
#include<QPainter>
#include<QDebug>
#include<QGuiApplication>
prelistwid::prelistwid(QWidget *parent):_global(0),QListWidget(parent),_last_index(17)
{
    this->setViewMode(QListWidget::IconMode);
    this->setIconSize(QSize(PICICON_SIZE,PICICON_SIZE));
    this->setSpacing(5);
    connect(this,&prelistwid::itemPressed,this,&prelistwid::SlotItemPressed);
}

void prelistwid::SlotUpSelect(QTreeWidgetItem *item)
{
    if(!item){
        return;

    }
    auto *pro_item=dynamic_cast<protreeitem*>(item);
    auto path=pro_item->GetPath();
    auto iter=_set_map.find(path);
    if(iter==_set_map.end()){
        return;
    }
    auto *list_item=dynamic_cast<prelistitem*>(iter.value());
    auto index =list_item->Getindex();
    if(index > 17){
        auto pos_cur = this->pos();
        this->move(pos_cur.x()-(index-_last_index)*100, pos_cur.y());
        _last_index = index;

    }else{
//        auto pos_cur = this->pos();
//        qDebug()<< "pos_cur is " << pos_cur << "origin_point is " << _origin_point << endl;
       this->move(_pos_origin);
        _last_index = 17;
    }
    this->setCurrentItem(iter.value());
}
void prelistwid::addlistitem(const QString &path)
{
    QPixmap src_pixmap(path);
    src_pixmap=src_pixmap.scaled(PICICON_SIZE,PICICON_SIZE,Qt::KeepAspectRatio);
    QPixmap dist_pixmap(QSize(PICICON_SIZE,PICICON_SIZE));
    dist_pixmap.fill(QColor(220,220,220,50));
    QPainter painter(&dist_pixmap);
    auto src_width=src_pixmap.width();
    auto src_height=src_pixmap.height();
    auto dist_width=dist_pixmap.width();
    auto dist_height=dist_pixmap.height();
    auto x=(dist_width-src_width)/2;
    auto y=(dist_height-src_height)/2;
    painter.drawPixmap(x,y,src_pixmap);
    _global++;
    prelistitem *pitem=new prelistitem(QIcon(dist_pixmap),path,_global,this);
    pitem->setSizeHint(QSize(PREITEM_SIZE,PREITEM_SIZE));
    this->addItem(pitem);

    _set_map[path]= pitem;

    if(_global==1){
        _pos_origin = this->pos();
    }
}
void prelistwid::SlotUpPreList(QTreeWidgetItem *item)
{
    qDebug()<<"SlotUpPreList is work"<<endl;
    if(!item){
        return;
    }
    auto *pro_item=dynamic_cast<protreeitem*>(item);
    auto path= pro_item->GetPath();
    auto iter =_set_map.find(path);
    if(iter!=_set_map.end()){
        return;
    }
    addlistitem(path);

}

void prelistwid::SlotItemPressed(QListWidgetItem *item)
{
    if(QGuiApplication::mouseButtons()!=Qt::LeftButton){
        return;
    }
    auto *list_item=dynamic_cast<prelistitem*>(item);
    auto cur_index=list_item->Getindex();
    auto path=list_item->Getpath();
    this->setCurrentItem(item);
    emit slotupselectshow(path);
}
