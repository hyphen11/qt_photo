#ifndef PICBTN_H
#define PICBTN_H

#include <QPushButton>

class picbtn : public QPushButton
{
public:
    picbtn(QWidget *parent = nullptr);

    void seticons(const QString&normal,const QString&hover,const QString&pressed);
protected:
     bool event(QEvent *e) override;
private:
    void setnormalicon();
    void sethovericon();
    void setpressicon();

    QString _normal;
    QString _hover;
    QString _pressed;

};

#endif // PICBTN_H
