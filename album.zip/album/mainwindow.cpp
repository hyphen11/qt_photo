#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "wizard.h"
#include "protree.h"
#include "picshow.h"
#include "protreewidget.h"
#include <QMenu>
#include<QAction>
#include<QDebug>
#include<QFileDialog>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    this->setMinimumSize(1629,869);
    ui->setupUi(this);
    //创建菜单
    QMenu *menu_file=menuBar()->addMenu(tr("文件(&F)"));
    QAction *act_create_pro=new QAction(QIcon(":/icon/createpro.png"),tr("创建项目"),this);
    act_create_pro->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_N));
    menu_file->addAction(act_create_pro);

    QAction *act_open_pro=new QAction(QIcon(":/icon/openpro.png"),tr("打开项目"),this);

    act_open_pro->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_O));
    menu_file->addAction(act_open_pro);

    //创建设置菜单
    QMenu *menu_set=menuBar()->addMenu(tr("设置(&Q)"));
    QAction *act_music=new QAction(QIcon(":/icon/music.png"),tr("背景音乐"),this);
    act_music->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_M));
    menu_set->addAction(act_music);


    connect(act_open_pro,&QAction::triggered,this,&MainWindow::slotopenpro);
    connect(act_create_pro,&QAction::triggered,this,&MainWindow::Slotcreatepro);
    _protree=new protree();
    ui->prolayout->addWidget(_protree);

    auto tree_widget_foropen=dynamic_cast<protree*>(_protree)->gettreewidget();

    auto  tree_widget=dynamic_cast<protreewidget*>(tree_widget_foropen);

    connect(this,&MainWindow::sigopenpro,tree_widget,&protreewidget::slot_openpro);
    _picshow=new picshow();
    ui->riclayout->addWidget(_picshow);
    auto *pro_picshow=dynamic_cast<picshow*>(_picshow);
    connect(tree_widget,&protreewidget::sigupdateselected,
            pro_picshow,&picshow::slotselectitem);
    connect(pro_picshow,&picshow::signextclicked,tree_widget,&protreewidget::slotnextshow);
    connect(pro_picshow,&picshow::sigpreclicked,tree_widget,&protreewidget::slotpreshow);
    connect(act_music,&QAction::triggered,tree_widget,&protreewidget::Slotsetmusic);
    connect(tree_widget,&protreewidget::sigupdatepic,pro_picshow,&picshow::updatepicshow);

    connect(tree_widget,&protreewidget::sigclearselected,pro_picshow,&picshow::slotdeleteitem);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    auto *pro_pic_show=dynamic_cast<picshow*>(_picshow);
    pro_pic_show->reloadpic();
    QMainWindow::resizeEvent(event);
}

void MainWindow::Slotcreatepro(bool)
{
    qDebug()<<"触发act_create_pro信号"<<endl;
    Wizard wizard(this);
    wizard.setWindowTitle(tr("创建项目"));
    auto *page= wizard.page(0);
    page->setTitle(tr("设置项目配置"));
    connect(&wizard,&Wizard::sigprosettings,dynamic_cast<protree*>(_protree),&protree::addprototree);

    wizard.show();
    wizard.exec();
    //断开信号
    disconnect(&wizard);
}

void MainWindow::slotopenpro(bool)
{
    QFileDialog file_dialog;
    file_dialog.setFileMode(QFileDialog::Directory);
    file_dialog.setWindowTitle(tr("选择打开的文件夹"));
    file_dialog.setDirectory(QDir::currentPath());
    file_dialog.setViewMode(QFileDialog::Detail);
    QStringList filename_open;
    if(file_dialog.exec()){
       filename_open = file_dialog.selectedFiles();

    }
    if(filename_open.length()<=0){
        return;
    }
    QString import_path= filename_open.at(0);
    emit sigopenpro(import_path);
}

