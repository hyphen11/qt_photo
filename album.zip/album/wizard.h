#ifndef WIZARD_H
#define WIZARD_H

#include <QWizard>

namespace Ui {
class Wizard;
}

class Wizard : public QWizard
{
    Q_OBJECT

public:
    explicit Wizard(QWidget *parent = nullptr);
    ~Wizard();

private:
    void done(int result)override;
    Ui::Wizard *ui;
signals:
    void sigprosettings(const QString name,const QString path);
};

#endif // WIZARD_H
