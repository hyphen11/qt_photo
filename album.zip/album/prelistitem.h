#ifndef PRELISTITEM_H
#define PRELISTITEM_H

#include <QListWidgetItem>

class prelistitem : public QListWidgetItem
{
public:
    prelistitem(const QIcon&icon,const QString &text,const int&index,
                QListWidget *view = nullptr, int type = Type);
    int Getindex();
    QString Getpath();
private:
   QString _path;
   int _index;


};

#endif // PRELISTITEM_H
