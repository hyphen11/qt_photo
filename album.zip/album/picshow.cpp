#include "picshow.h"
#include "ui_picshow.h"
#include<QDebug>
picshow::picshow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::picshow)
{
    ui->setupUi(this);
    ui->previousbtn->seticons(":/icon/previous.png",":/icon/previous_hover.png",":/icon/previous_press.png");
    ui->nextbtn->seticons(":/icon/next.png",":/icon/next_hover.png",":/icon/next_press.png");

    QGraphicsOpacityEffect *opacity_pre=new QGraphicsOpacityEffect(this);
    opacity_pre->setOpacity(0);
    ui->previousbtn->setGraphicsEffect(opacity_pre);

    QGraphicsOpacityEffect *opacity_next=new QGraphicsOpacityEffect(this);
    opacity_next->setOpacity(0);
    ui->nextbtn->setGraphicsEffect(opacity_next);

    _animation_show_pre=new QPropertyAnimation(opacity_pre,"opacity",this);
    _animation_show_pre->setEasingCurve(QEasingCurve::Linear);
    _animation_show_pre->setDuration(500);

    _animation_show_next=new QPropertyAnimation(opacity_next,"opacity",this);
    _animation_show_next->setEasingCurve(QEasingCurve::Linear);
    _animation_show_next->setDuration(500);
    connect(ui->nextbtn,&QPushButton::clicked,this,&picshow::signextclicked);
    connect(ui->previousbtn,&QPushButton::clicked,this,&picshow::sigpreclicked);

}

picshow::~picshow()
{
    delete ui;
}

void picshow::reloadpic()
{
    if(_selectd_path!=""){
        const auto &width=ui->gridLayout->geometry().width();
        const auto &heght=ui->gridLayout->geometry().height();
        _pix_map.load(_selectd_path);

        _pix_map=_pix_map.scaled(width,heght,Qt::KeepAspectRatio);
        ui->label->setPixmap(_pix_map);
    }
}

bool picshow::event(QEvent *event)
{
    switch (event->type()) {
    case QEvent::Enter:
        showprenextbtns(true);
        break;
    case QEvent::Leave:
        showprenextbtns(false);
        break;
    default:
        break;
    }
    return QDialog::event(event);
}

void picshow::showprenextbtns(bool b_show)
{
    if(!b_show && _b_btnvisible){
        _animation_show_pre->stop();
        //动画 开始是1就是显示的-》end是0就是隐藏的
        _animation_show_pre->setStartValue(1);
        _animation_show_pre->setEndValue(0);
        _animation_show_pre->start();

        _animation_show_next->setStartValue(1);
        _animation_show_next->setEndValue(0);
        _animation_show_next->start();
        _b_btnvisible=false;
        return;
    }
    if( b_show && !_b_btnvisible){
        _animation_show_pre->stop();
        //动画 开始是1就是显示的->end是0就是隐藏的
        _animation_show_pre->setStartValue(0);
        _animation_show_pre->setEndValue(1);
        _animation_show_pre->start();

        _animation_show_next->setStartValue(0);
        _animation_show_next->setEndValue(1);
        _animation_show_next->start();
        _b_btnvisible=true;
        return;
    }

}

void picshow::slotselectitem(const QString &path)
{
    _selectd_path=path;
    _pix_map.load(path);
    auto width =this->width() ;
    auto height =this->height();
    _pix_map=_pix_map.scaled(width,height,Qt::KeepAspectRatio);
    ui->label->setPixmap(_pix_map);
}

void picshow::updatepicshow(const QString &path)
{
    _selectd_path=path;
    if(_selectd_path!=""){
        qDebug()<<"updatepicshow"<<endl;
        const auto &width=ui->gridLayout->geometry().width();
        const auto &heght=ui->gridLayout->geometry().height();
        _pix_map.load(_selectd_path);
        _pix_map=_pix_map.scaled(width,heght,Qt::KeepAspectRatio);
        ui->label->setPixmap(_pix_map);
    }
}

void picshow::slotdeleteitem()
{
   _selectd_path="";
}
