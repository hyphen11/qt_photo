#ifndef PICSHOW_H
#define PICSHOW_H
#include<QGraphicsOpacityEffect>
#include<QPropertyAnimation>
#include <QDialog>

namespace Ui {
class picshow;
}

class picshow : public QDialog
{
    Q_OBJECT

public:
    explicit picshow(QWidget *parent = nullptr);
    ~picshow();
    void reloadpic();
protected:
      bool event(QEvent *event) override;
private:
    void showprenextbtns(bool b_show);
    QString _selectd_path;
    QPixmap _pix_map;


    Ui::picshow *ui;
    QPropertyAnimation* _animation_show_pre;
    QPropertyAnimation* _animation_show_next;
    bool _b_btnvisible;
public slots:
    void slotselectitem(const QString &path);
    void updatepicshow(const QString &path);
    void slotdeleteitem();
signals:
    void signextclicked();
    void sigpreclicked();

};



#endif // PICSHOW_H
