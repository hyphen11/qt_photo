#ifndef PRELISTWID_H
#define PRELISTWID_H

#include <QListWidget>
#include<QTreeWidgetItem>
class prelistwid : public QListWidget
{
    Q_OBJECT
private:
    QMap<QString,QListWidgetItem*>_set_map;
    void addlistitem(const QString &path);
    int _global;
    QPoint _pos_origin;
    int _last_index;
public:
    prelistwid(QWidget *parent = nullptr);

public slots:
    void SlotUpSelect(QTreeWidgetItem *item);
    void SlotUpPreList(QTreeWidgetItem *item);
    void SlotItemPressed(QListWidgetItem *item);
signals:
    void slotupselectshow(QString path);

};



#endif // PRELISTWID_H
