#include "picstatebtn.h"
#include"const.h"
#include<QEvent>

picstatebtn::picstatebtn(QWidget *parent):QPushButton(parent)
{

}

void picstatebtn::seticons(const QString &normal, const QString &hover, const QString &pressed,
                           const QString &normal_2, const QString &hover_2, const QString &pressed_2)
{
    _normal=normal;
    _hover=hover;
    _pressed=pressed;
    _normal_2=normal_2;
    _hover_2=hover_2;
    _pressed_2=pressed_2;
    QPixmap temppixmap;
    temppixmap.load(normal);
    this->resize(temppixmap.size());
    this->setIcon(temppixmap);
    this->setIconSize(temppixmap.size());
    _cur_state=PicBtnStateNormal;
}

picstatebtn::~picstatebtn()
{

}

bool picstatebtn::event(QEvent *e)
{
    switch (e->type()) {
        case  QEvent::Enter:
            if(_cur_state<PicBtnState2Normal){
                sethovericon();
            }else{
                 sethover2icon();
            }
            break;
        case  QEvent::Leave:
            if(_cur_state<PicBtnState2Normal){
                setnormalicon();
          }else{
                setnormal2icon();
                 }
            break;
        case  QEvent::MouseButtonPress:
            if(_cur_state<PicBtnState2Normal){
                setpressedicon();
        }else{
               setpressed2icon();
                }
            break;
        case  QEvent::MouseButtonRelease:
            if(_cur_state<PicBtnState2Normal){
                sethover2icon();
        }else{
            sethovericon();
                }
            break;
        default:
            break;

    }
    return QPushButton::event(e);

}

void picstatebtn::setnormalicon()
{

    QPixmap temppixmap;
    temppixmap.load(_normal);
    this->setIcon(temppixmap);
     _cur_state=PicBtnStateNormal;
}
void picstatebtn::sethovericon()
{
    QPixmap temppixmap;
    temppixmap.load(_hover);
    this->setIcon(temppixmap);
     _cur_state=PicBtnStateHover;
}

void picstatebtn::setpressedicon()
{
    QPixmap temppixmap;
    temppixmap.load(_pressed);
    this->setIcon(temppixmap);
     _cur_state=PicBtnStatePRESS;
}

void picstatebtn::setnormal2icon()
{
    QPixmap temppixmap;
    temppixmap.load(_normal_2);
    this->setIcon(temppixmap);
     _cur_state=PicBtnState2Normal;
}

void picstatebtn::sethover2icon()
{
    QPixmap temppixmap;
    temppixmap.load(_hover_2);
    this->setIcon(temppixmap);
     _cur_state=PicBtnState2Hover;
}

void picstatebtn::setpressed2icon()
{
    QPixmap temppixmap;
    temppixmap.load(_pressed_2);
    this->setIcon(temppixmap);
    _cur_state=PicBtnState2PRESS;
}

void picstatebtn::SlotStart()
{
    setnormal2icon();
}

void picstatebtn::SlotStop()
{
    setnormalicon();
}
