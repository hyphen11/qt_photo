#ifndef SILDESHOW_H
#define SILDESHOW_H

#include <QDialog>
#include<QTreeWidgetItem>
namespace Ui {
class sildeshow;
}

class sildeshow : public QDialog
{
    Q_OBJECT

public:
    explicit sildeshow(QWidget *parent ,QTreeWidgetItem* first_item,QTreeWidgetItem* last_item);
    ~sildeshow();

private:
    Ui::sildeshow *ui;
    QTreeWidgetItem* _first_item;
    QTreeWidgetItem* _last_item;
public slots:
    void slotslidepre();
    void slotslidenext();
};

#endif // SILDESHOW_H
