#ifndef REMOVEPRO_H
#define REMOVEPRO_H

#include <QDialog>

namespace Ui {
class removepro;
}

class removepro : public QDialog
{
    Q_OBJECT

public:
    explicit removepro(QWidget *parent = nullptr);
    ~removepro();
    bool isremoved();

private:
    Ui::removepro *ui;
};

#endif // REMOVEPRO_H
