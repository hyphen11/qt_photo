#include "protreeitem.h"
#include"const.h"
protreeitem::protreeitem(QTreeWidget *view, const QString &name,
                         const QString &path, int type)
    :QTreeWidgetItem (view, type),_path(path),_name(name),_root(this),_pre_item(nullptr),_next_item(nullptr)
{

}
protreeitem::protreeitem(QTreeWidgetItem*parent,const QString &name,
            const QString&path,QTreeWidgetItem*root,int type)
    :QTreeWidgetItem(parent,type),_path(path),_name(name),_root(root),_pre_item(nullptr),_next_item(nullptr)

{

}

const QString &protreeitem::GetPath()
{
    return _path;
}

QTreeWidgetItem *protreeitem::Getroot()
{
    return _root;
}

void protreeitem::SetPreItem(QTreeWidgetItem *item)
{
    _pre_item=item;

}

void protreeitem::SetNextItem(QTreeWidgetItem *item)
{
    _next_item=item;
}

protreeitem *protreeitem::GetPreItem()
{
    return dynamic_cast<protreeitem *>(_pre_item);
}

protreeitem *protreeitem::GetNextItem()
{
    return dynamic_cast<protreeitem *>(_next_item);
}

protreeitem *protreeitem::GetLastPicChild()
{
    if(this->type()==TreeItemPic){
        return nullptr;

    }
  auto child_count=this->childCount();//取出所有的子节点的数量
  if(child_count==0){
      return nullptr;

  }
  for(int i=child_count-1;i>=0;i--){
     auto *last_child=this->child(i);
     auto *last_child_item=dynamic_cast<protreeitem*>(last_child);
     int item_type=last_child_item->type();

     if(item_type==TreeItemPic){
         return last_child_item;
     }

     last_child=last_child_item->GetLastPicChild();

     if(!last_child){
         continue;
     }

     last_child_item=dynamic_cast<protreeitem*>(last_child);
     return last_child_item;
  }
     return nullptr;
}

protreeitem *protreeitem::GetFirstPicChild()
{
    if(this->type()==TreeItemPic){
        return nullptr;
    }
  auto child_count=this->childCount();//取出所有的子节点的数量
  if(child_count==0){
      return nullptr;

  }
  for(int i=0;i<=child_count-1;i++){
     auto *last_child=this->child(i);
     auto *last_child_item=dynamic_cast<protreeitem*>(last_child);
     int item_type=last_child_item->type();

     if(item_type==TreeItemPic){
         return last_child_item;
     }

     last_child=last_child_item->GetFirstPicChild();

     if(!last_child){
         continue;
     }

     last_child_item=dynamic_cast<protreeitem*>(last_child);
     return last_child_item;
  }
     return nullptr;
}
