#ifndef PROTREEITEM_H
#define PROTREEITEM_H
#include"protreewidget.h"
#include <QTreeWidgetItem>

class protreeitem : public QTreeWidgetItem
{
public:
    protreeitem(QTreeWidget*view,const QString &name,const QString&path,int type=Type);
    protreeitem(QTreeWidgetItem*parent,const QString &name,
                 const QString&path,QTreeWidgetItem*root,int type=Type);
    const QString& GetPath();
    QTreeWidgetItem *Getroot();
    void SetPreItem(QTreeWidgetItem *item);
    void SetNextItem(QTreeWidgetItem *item);
    protreeitem *GetPreItem();
    protreeitem *GetNextItem();
    protreeitem *GetLastPicChild();
    protreeitem *GetFirstPicChild();
   // protreeitem(protreewidget* widget, const QString &name, QString &path,int type=Type);
private:
    QString _path;
    QString _name;
    QTreeWidgetItem *_root;
    QTreeWidgetItem *_pre_item;
    QTreeWidgetItem *_next_item;

};

#endif // PROTREEITEM_H
