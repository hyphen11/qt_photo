#ifndef PROTREEWIDGET_H
#define PROTREEWIDGET_H
#include<QProgressDialog>
#include <QTreeView>
#include<QTreeWidget>
#include<QAction>
#include "protreethread.h"
#include"opentreed.h"
#include<QtMultimedia/QMediaPlayer>
#include<QtMultimedia/QMediaPlaylist>

class sildeshow;

class protreewidget : public QTreeWidget
{
    Q_OBJECT
public:
    protreewidget(QWidget *parent = nullptr);
    void addprototree(const QString&name,const QString&path);
private:
    QSet<QString>_set_path;
    QTreeWidgetItem * right_btn_item;
    QTreeWidgetItem*_active_item;//保存当前启动项目
    QTreeWidgetItem*_selected_item;
    QAction *_action_import;
    QAction *_action_setstart;
    QAction *_action_closepro;
    QAction *_action_slideshow;
    QProgressDialog *_dialog_progress;
    QProgressDialog * open_progressdlg;
    std::shared_ptr<protreethread> _thread_create_pro;
    std::shared_ptr<OpenTreeThread> _thread_open_pro;
    std::shared_ptr<sildeshow>_slide_show_dlg;
    QMediaPlayer *_player;
    QMediaPlaylist*_play_list;

private slots:
    void SlotDoubleClickedItem (QTreeWidgetItem *doubleitem, int col);
    void SlotItemPressed(QTreeWidgetItem *item, int column);
    void Slotimport();
    void slotupdateprogress(int count);
    void slotfinishprogress();
    void slotcancelprogress();
    void Slotsetactive();
    void Slotcloseitem();
    //打开取消的操作
     void slotupdateopenprogress(int count);
     void slotfinishopenprogress();
     void slotcancelopenprogress();
     void slotslideshow();

public slots:
    void slot_openpro(const QString&path);
    void slotnextshow();
    void slotpreshow();
    void Slotsetmusic();
    void SlotStartMusic();
    void SlotStopMusic();
signals:
    void sigcancelprogress();
    void sigcancelopenprogress();
    void sigupdateselected(const QString &);
    void sigupdatepic(const QString&);
    void sigclearselected();
};


#endif // PROTREEWIDGET_H
