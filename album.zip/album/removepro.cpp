#include "removepro.h"
#include "ui_removepro.h"

removepro::removepro(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::removepro)
{
    ui->setupUi(this);
}

removepro::~removepro()
{
    delete ui;
}

bool removepro::isremoved()
{
     bool bchecked=ui->checkBox->isChecked();
     return bchecked;
}
