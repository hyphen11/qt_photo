#include "picbtn.h"
#include<QPixmap>
#include<QEvent>
picbtn::picbtn(QWidget *parent)
{

}

void picbtn::seticons(const QString &normal, const QString &hover,
                     const QString &pressed)
{
    _normal=normal;
    _hover=hover;
    _pressed=pressed;
    QPixmap tmppixmap;
    tmppixmap.load(normal);
    this->resize(tmppixmap.size());
    this->setIcon(tmppixmap);
    this->setIconSize(tmppixmap.size());

}

bool picbtn::event(QEvent *e)
{
    switch (e->type()) {
        case QEvent::Enter:
            sethovericon();
            break;
        case QEvent::Leave:
            setnormalicon();
            break;
        case QEvent::MouseButtonPress:
             setpressicon();
             break;
        case QEvent::MouseButtonRelease:
             sethovericon();
             break;
    default:
        break;

    }
    return QPushButton::event(e);
}

void picbtn::setnormalicon()
{
    QPixmap tmppixmap;
    tmppixmap.load(_normal);
    this->setIcon(tmppixmap);

}

void picbtn::sethovericon()
{
    QPixmap tmppixmap;
    tmppixmap.load(_hover);
    this->setIcon(tmppixmap);
}

void picbtn::setpressicon()
{
    QPixmap tmppixmap;
    tmppixmap.load(_pressed);
    this->setIcon(tmppixmap);
}
