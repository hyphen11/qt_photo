#ifndef PICSTATEBTN_H
#define PICSTATEBTN_H

#include <QPushButton>

class picstatebtn : public QPushButton
{
public:
    picstatebtn(QWidget *parent = nullptr);
    void seticons(const QString&normal,const QString&hover,const QString&pressed,
                  const QString&normal_2,const QString&hover_2,const QString&pressed_2);
     virtual ~picstatebtn() override;
protected:
    bool event(QEvent *e) override;
private:
    void setnormalicon();
    void sethovericon();
    void setpressedicon();
    void setnormal2icon();
    void sethover2icon();
    void setpressed2icon();
    QString _normal;
    QString _hover;
    QString _pressed;
    QString _normal_2;
    QString _hover_2;
    QString _pressed_2;
    int _cur_state;
public slots:
    void SlotStart();
    void SlotStop();

};

#endif // PICSTATEBTN_H
