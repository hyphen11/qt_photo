#ifndef PROTREE_H
#define PROTREE_H
#include<QTreeWidget>
#include <QDialog>

namespace Ui {
class protree;
}

class protree : public QDialog
{
    Q_OBJECT

public:
    explicit protree(QWidget *parent = nullptr);
    ~protree();
     QTreeWidget* gettreewidget();
private:
    Ui::protree *ui;
public slots:
    void addprototree(const QString name,const QString path);
};

#endif // PROTREE_H
