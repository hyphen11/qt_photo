#include "picanimationwid.h"
#include"protreeitem.h"
#include<QTimer>
#include<QPainter>
picanimationwid::picanimationwid(QWidget *parent) :
    QWidget(parent),_factor(0.0),_cur_item(nullptr),_b_start(false)
{
    _timer =new QTimer(this);
    connect(_timer,&QTimer::timeout,this,&picanimationwid::TimeOut);

}

void picanimationwid::SetPixmap(QTreeWidgetItem *item)
{
    if(!item){
        return;

    }
    auto *tree_item=dynamic_cast<protreeitem*>(item);
    auto path =tree_item->GetPath();
    _pixmap1.load(path);
    _cur_item=tree_item;
    if(_map_items.find(path)==_map_items.end()){
        _map_items[path]=tree_item;
        //发送更新列表逻辑
        //emit SlotUpSelectShow(path);
        emit SigUpPreList(item);
    }
     emit SigSelectItem(item);
    auto*next_item=tree_item->GetNextItem();
    if(!next_item){
        return;
    }
     auto next_path =next_item->GetPath();
    _pixmap2.load(next_path);
    if(_map_items.find(next_path)==_map_items.end()){
        _map_items[next_path]=next_item;
         //emit SlotUpSelectShow(next_path);
         emit SigUpPreList(next_item);
    }



}

void picanimationwid::Stop()
{
    _timer->stop();
    _factor=0;
    _b_start=false;
    emit SigStop();
    emit SigStopMusic();
}

void picanimationwid::slidenext()
{
    Stop();
    if(!_cur_item){
        return;
    }
    auto *cur_pro_item=dynamic_cast<protreeitem*>(_cur_item);
    auto *next_item=cur_pro_item->GetNextItem();
    SetPixmap(next_item);
    update();
}

void picanimationwid::SlidePre()
{
    Stop();
    if(!_cur_item){
        return;
    }
    auto *cur_pro_item=dynamic_cast<protreeitem*>(_cur_item);
    auto *pre_item=cur_pro_item->GetPreItem();
    SetPixmap(pre_item);
    update();
}

void picanimationwid::paintEvent(QPaintEvent *event)
//这个函数定义怎么加载图片
//当窗口首次被创建、显示或者窗口被覆盖、最小化后再恢复时，paintEvent会被触发以绘制窗口的内容。
{
    //实现图片的绘制效果
    if(_pixmap1.isNull()){
        return;
    }
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing,true);
    QRect rect=geometry();
    int w=rect.width();
    int h=rect.height();

    if(!_pixmap1){
        return;
    }
    _pixmap1=_pixmap1.scaled(w,h,Qt::KeepAspectRatio);
    int alpgha=255*(1.0f-_factor);
    QPixmap alphapixmap(_pixmap1.size());
    alphapixmap.fill(Qt::transparent);//填充透明的图

    QPainter p1(&alphapixmap);
    p1.setCompositionMode(QPainter::CompositionMode_Source);
    p1.drawPixmap(0,0,_pixmap1);
    p1.setCompositionMode(QPainter::CompositionMode_DestinationIn);
    p1.fillRect(alphapixmap.rect(),QColor(0,0,0,alpgha));
    p1.end();

    int x=(w-alphapixmap.width())/2;
    int y=(h-alphapixmap.height())/2;
    painter.drawPixmap(x,y,alphapixmap);

    if(!_pixmap2){
        return;
    }
     _pixmap2=_pixmap2.scaled(w,h,Qt::KeepAspectRatio);
    int alpha=255*(_factor);
    QPixmap alphapixmap2(_pixmap2.size());
    alphapixmap2.fill(Qt::transparent);//填充透明的图
    QPainter p2(&alphapixmap2);
    p2.setCompositionMode(QPainter::CompositionMode_Source);
    p2.drawPixmap(0,0,_pixmap2);
    p2.setCompositionMode(QPainter::CompositionMode_DestinationIn);
    //根据透明度alpgha做显示
    p2.fillRect(alphapixmap2.rect(),QColor(0,0,0,alpha));
    p2.end();
    x=(w-alphapixmap2.width())/2;
    y=(h-alphapixmap2.height())/2;
    painter.drawPixmap(x,y,alphapixmap2);

}

void picanimationwid::Upslectpixmap(QTreeWidgetItem *item)
{
    if(!item){
        return;
    }
    auto tree_item=dynamic_cast<protreeitem*>(item);
    auto path=tree_item->GetPath();

    _pixmap1.load(path);
    _cur_item=tree_item;
    if(_map_items.find(path)==_map_items.end()){
    _map_items[path]=tree_item;
    }

    auto *next_item=tree_item->GetNextItem();
    if(!next_item){
        return;
    }
    auto next_path=next_item->GetPath();
    if(_map_items.find(next_path)==_map_items.end()){
    _map_items[next_path]=next_item;
    }


}

void picanimationwid::SlotStartOrStop()
{
    if(!_b_start){
        _factor=0;
        _timer->start(25);
        _b_start=true;
        emit SigStartMusic();

    }else {
    _timer->stop();
      _factor=0;
      update();
      _b_start=false;
      emit SigStopMusic();
}
}

void picanimationwid::SlotUpSelectShow(QString path)
{
    auto iter=_map_items.find(path);
    if(iter==_map_items.end()){
        return;
    }
    Upslectpixmap(iter.value());
    update();

}
void picanimationwid::Start()
{
      _factor=0;
      _timer->start(25);
      _b_start=true;
      emit SigStart();
      emit SigStartMusic();
}

void picanimationwid::TimeOut()
{

    if(!_cur_item){
        Stop();
        update();
        return;
    }
    //每次TimeOut触发的时候_factor+0.01;
    _factor=_factor+0.01;
    if(_factor>=1){
        _factor=0;
        auto *cur_pro_item=dynamic_cast<protreeitem*>(_cur_item);
        auto *next_pro_item=cur_pro_item->GetNextItem();
        if(!next_pro_item){
            Stop();
            update();
            return;
        }
        SetPixmap(next_pro_item);
        update();
        return;
    }
    //调用 update() 请求重新绘制窗口，以更新图片的显示。
       update();
}
