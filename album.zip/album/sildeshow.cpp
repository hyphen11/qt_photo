#include "sildeshow.h"
#include "ui_sildeshow.h"
#include"prelistwid.h"
#include "picanimationwid.h"
#include "protreewidget.h"
sildeshow::sildeshow(QWidget *parent, QTreeWidgetItem *first_item, QTreeWidgetItem *last_item):
    QDialog(parent),_first_item(first_item),_last_item(last_item),
    ui(new Ui::sildeshow)
{
     ui->setupUi(this);
     this->setWindowFlags(Qt::Dialog|Qt::FramelessWindowHint);
     ui->sildeprebtn->seticons(":/icon/previous.png",":/icon/previous_hover.png",":/icon/previous_press.png");
     ui->sildenextbtn->seticons(":/icon/next.png",
                                ":/icon/next_hover.png",
                                ":/icon/next_press.png");
     ui->closebtn->seticons(":/icon/closeshow.png",":/icon/closeshow_hover.png",
                            ":/icon/closeshow_press.png");
     ui->playbtn->seticons(":/icon/play.png",":/icon/play_hover.png",":/icon/play_press.png",
                           ":/icon/pause.png",":/icon/pause_hover.png",":/icon/pause_press.png");
     connect(ui->closebtn,&QPushButton::clicked,this,&sildeshow::close);//继承的close
     connect(ui->sildenextbtn,&QPushButton::clicked,this,&sildeshow::slotslidenext);
     connect(ui->sildeprebtn,&QPushButton::clicked,this,&sildeshow::slotslidepre);
     auto* prelistwidget=dynamic_cast<prelistwid*>(ui->prelistWidget);
     connect(ui->picanimation,&picanimationwid::SigUpPreList,prelistwidget,&prelistwid::SlotUpPreList);
     connect(ui->picanimation,&picanimationwid::SigSelectItem,prelistwidget,&prelistwid::SlotUpSelect);
     connect(prelistwidget,&prelistwid::slotupselectshow,ui->picanimation,&picanimationwid::SlotUpSelectShow);
     connect(ui->playbtn,&picstatebtn::clicked,ui->picanimation,&picanimationwid::SlotStartOrStop);
     connect(ui->picanimation,&picanimationwid::SigStart,
             ui->playbtn,&picstatebtn::SlotStart);
     connect(ui->picanimation,&picanimationwid::SigStop,
             ui->playbtn,&picstatebtn::SlotStop);
     auto *protree_widget=dynamic_cast<protreewidget*>(parent);

     connect(ui->picanimation,&picanimationwid::SigStartMusic,
            protree_widget,&protreewidget::SlotStartMusic);

     connect(ui->picanimation,&picanimationwid::SigStopMusic,
            protree_widget,&protreewidget::SlotStopMusic);
     ui->picanimation->SetPixmap(_first_item);

     ui->picanimation->Start();


}

sildeshow::~sildeshow()
{
    delete ui;
}

void sildeshow::slotslidepre()
{
    ui->picanimation->SlidePre();
}

void sildeshow::slotslidenext()
{
    ui->picanimation->slidenext();
}
