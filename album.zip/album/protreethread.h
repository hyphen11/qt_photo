#ifndef PROTREETHREAD_H
#define PROTREETHREAD_H
#include<QTreeWidget>
#include <QThread>

class protreethread : public QThread
{
    Q_OBJECT
public:
    protreethread(const QString &src_path, const QString &dist_path,
                  QTreeWidgetItem *parent_item, int &file_count,
                  QTreeWidget *self, QTreeWidgetItem *root, QObject *parent);

    ~protreethread();
protected:
    virtual void run();
private:
    void createprotree(const QString &src_path, const QString &dist_path,
                       QTreeWidgetItem *parent_item, int &file_count,QTreeWidget *self,
                       QTreeWidgetItem *root, QTreeWidgetItem *preitem=nullptr);
    QString _src_path;
    QString _dist_path;
    QTreeWidgetItem *_parent_item;
    QTreeWidget *_self;
    QTreeWidgetItem *_root;
    bool _bstop;
   int _file_count;
public slots:
   void slotcancelprogress();
    void slotcancelopenprogress();
signals:
   void sigupdateprogress(int);
   void sigfinishprogress(int);
};

#endif // PROTREETHREAD_H
